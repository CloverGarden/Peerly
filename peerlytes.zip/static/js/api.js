// api.js — thin fetch wrapper + token store
const API_BASE = (() => {
  // same origin by default (saat backend serve static); override via localStorage
  const custom = localStorage.getItem('bb_api_base');
  if (custom) return custom;
  if (location.port === '4000') return '';          // served by backend
  if (location.protocol === 'file:') return 'http://localhost:4000';
  // Vite / live-server mode
  if (location.port && location.port !== '80' && location.port !== '443' && location.port !== '4000')
    return 'http://localhost:4000';
  return '';
})();

const TOKEN_KEY = 'bb_token';
const USER_KEY  = 'bb_user';

export function getToken() { return localStorage.getItem(TOKEN_KEY); }
export function setToken(t) { localStorage.setItem(TOKEN_KEY, t); }
export function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}
export function getUser() {
  try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); }
  catch { return null; }
}
export function setUser(u) { localStorage.setItem(USER_KEY, JSON.stringify(u)); }

export async function api(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const t = getToken();
    if (t) headers['Authorization'] = `Bearer ${t}`;
  }
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};
  if (!res.ok) {
    const err = new Error(data.error || `HTTP ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

export function requireAuth(expectedRole) {
  const user = getUser();
  if (!user || !getToken()) {
    location.href = '/pages/login.html';
    return null;
  }
  if (expectedRole && user.role !== expectedRole) {
    location.href = '/pages/dashboard.html';
    return null;
  }
  return user;
}

export function logout() {
  clearSession();
  location.href = '/index.html';
}
